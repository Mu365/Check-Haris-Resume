const profileData = {
  title: "Resume",
  name: "Muhammad Haris",
  sub_title: "Electrical Engineer/ Major Computing Engineering",
  logoURL: "assets/images/dp.jpg",
  about: {
    intro: `I am an innovative and passionate developer with a primary interest in <strong>Django $ Flask Pyhton</strong>
     and its applications on AWS. Experienced in designing and implementing sophisticated UI/UX with
      Progressive Web Application standards and application life-cycle management.`,
    contact: {
      email: "haris2020@namal.edu.pk",
      phone: "+92-3090295583",
      address: "Punjab, Pakistan"
    }
  },
  links: [
    { title: "Youtube", src: "https://www.youtube.com/channel/UCBQJctvYr0P-L_sIifN1lGg" },
    { title: "Github", src: "https://github.com/Mu365" },
    { title: "LinkedIn", src: "https://www.linkedin.com/in/muhammad-haris-476261218/" }
    // { title: 'Twitter', src: 'https://twitter.com/imvpn22' }
    // { title: 'HackerEarth', src: 'https://www.hackerearth.com/@imvpn22' },
  ],
  education: [
    {
      alma: "Namal University, Mianwali",
      duration: "2020 - 2024",
      std: "BS. (Computer Science & Engineering)",
      score: "85%"
    },
    {
      alma: "Punjab Danish School, Mianwali",
      duration: "2018 - 2020",
      std: "Class XI-XII (FSC)",
      score: "85.46%"
    },
    {
      alma: "Punjab Danish School, Mianwali",
      duration: "2016 - 2018",
      std: "Class IX - X (Matric)",
      score: "96.33%"
    }
  ],
  skills: [
    {
      category: "Programming Languages",
      topics: ["Python", "C/C++","HTML/CSS/JAVASCRIPT", "PHP","AWS", "GITHUB","ARDUINO IDE CODING","MATLAB CODING","MACHINE LEARNING"]
    },
    {
      category: "Frameworks / Libraries",
      topics: [
        "DJNGO",
        "FLASK",
        "STREAMLIT",
        "PYHTON GUI",
        "MYADMINPHP",
        "ANGULAR",
        "BOOTSTRAP",
        "TKINTER",
        "SKLEARN"
      ]
    }
  ],
  projects: [
    {
      title: "Smart Foot Weight Analytics For Health Diagnosis Using Machine Learning",
      duration: "Jan - July 2024",
      link: "https://github.com/Mu365/Smart-Foot-Weight-Analytics-For-Health-Diagnosis(FYP)",
      desc: `Correct weight distribution on feet are emerging concepts in the medical science.
      Smart Foot Weight Analytics system is an intelligent tool that measures weight distribution on different parts of foot.
      Healthy foot weight distribution is Forefoot 28% to 35%,Medial 14% to 19% , Rear foot 46% to 54%.`
    },
    {
      title: "Foot Analytics App Using Low Code Python Framwork",
      duration: "Sep - Dec 2023",
      link: "https://github.com/Mu365/Foot-Analytics-App-",
      desc: `A  <strong>web-app for foot analytics for health diagnosis</strong>.
      The app includes a real-time analytics and sketching platform for collaboration.
      It also has features to train model.
      Developed using <strong>Streamlit in Python</strong> Depolyed at AWS Server,
      <strong>Low Code</strong>, <strong>Python</strong>.`
    },
    {
      title: "Programmer Blog Website Using Flask",
      duration: "April 2024",
      link: "https://github.com/Mu365",
      desc: `A sophisticated <strong>web-app for programmer blog using flask Python Development Fr</strong>.
      The app includes a real-time blog and sketching platform for users.
      It also has features to train model.
      Developed using <strong>Flask in Python</strong> Depolyed at AWS Server,
      <strong>MyAdminPHP</strong>.`
    },
    {
      title: "IT Solution Company Website Using Django",
      duration: "May 2024",
      link: "https://github.com/Mu365",
      desc: `A user friendly <strong>website for programmer blog using Django Python Development </strong>.
      The app includes a real-time Services and sketching platform for users.
      It also has features for user.
      Developed using <strong>Django in Python</strong> Depolyed at AWS Server,
      <strong>SQLITE</strong>.`
    },
    {
      title: "UI/UX Design for Covid-19 ",
      duration: "june 2024",
      link: "https://mharisf.carrd.co/",
      desc: `A user friendly <strong>website for covid-2019 </strong>.
      The app includes a real-time Services and sketching platform for users.
      It also has features for user.
      Developed using Figma<strong>FIGMA</strong> Added at Card.`
    },
    {
      title: "An intelligent attendance system",
      duration: "FEB 2024",
      link: "https://github.com/Mu365/intelligent-Attendance-System-",
      desc: `An Intelligent Attendance System refers to a technologically advanced solution for tracking and managing 
      attendance in various settings, such as schools, colleges, offices, and other organizations. This system typically 
      utilizes modern technologies to automate the attendance process, making it more efficient, accurate, and less prone to errors.`
    },
    {
      title: "Age & Gender Detection Using Machine Learning Model",
      duration: "March 2024",
      link: "https://github.com/Mu365/Age-Through-Face-using-Machine-Learning",
      desc: `An age & Gender detection System using Machine Learning is a technologically advanced for detecting age and gender managing 
      attendance in various settings, such as schools, colleges, offices, and other organizations. This system typically 
      utilizes modern technologies to automate the attendance process, making it more efficient, accurate, and less prone to errors.`
    },
  ],
  experiences: [
    {
      organization: "Samail HyperMarket in Oman",
      title: `Acountant Manager & Data Analytics `,
      date: "Jan-2023",
      details: [
        `As a Accountant and Data Analytis  , I worked handling account & communicating with different companies.<strong>i experienced very well growmed</strong> Caring customer is somewhat difficult task but i always tried to calm and commuicate with them humbly , 
        which is actually task assigned to me.`,
        `Other responsibilities involve adding more cutomer values to company through graphics skill.`
      ]
    },
    {
      organization: "Wapda(water and power development authority",
      title: `Interne `,
      date: "Nov 2023",
      details: [
        `Worked on the site of hydal power at different stations
        <strong>All Stations</strong> with <strong>Practicaly learning mode</strong> and <strong>Resposible</strong> to maintain SOPs
        with protobuf for the WAPDA.`,
        
      ]
    },
    
  ],
  certifications: [
    {
      desc: `<strong>Hydal Power Wapda Chasma</strong> Internship <strong>Phase 1</strong>.
      (<a target='_blank' rel='noreferrer' href='https://drive.google.com/file/d/1FkMc0HnAAQghsSSjeSBf5KIrBAlOAtt5/view?usp=sharing'>https://drive.google.com/file/d/1FkMc0HnAAQghsSSjeSBf5KIrBAlOAtt5/view?usp=sharing</a>)`,
      date: "Nov 2023"
    },
    {
      desc: `<strong>Machine Learning Internship </strong>, Codealpha. Did Project <strong> Song Recommendation system  </strong>secures distinction among more than 2500 candidates.
       (<a target='_blank' rel='noreferrer' href='https://github.com/Mu365/Song-Recommendation-System-'>
       https://github.com/Mu365/Song-Recommendation-System-</a>)`,
      date: "Jan - Mar 2024"
    }
  ],
  events: []
};
